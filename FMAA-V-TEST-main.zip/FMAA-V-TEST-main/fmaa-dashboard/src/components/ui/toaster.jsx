// Simple toaster implementation for FMAA dashboard
export function Toaster() {
  return null // Placeholder for now
}

